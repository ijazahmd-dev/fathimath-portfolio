<!DOCTYPE html><!-- Last Published: Tue Sep 29 2026 20:38:38 GMT+0000 (Coordinated Universal Time) --><html data-wf-domain="bermawy.com" data-wf-page="656e2ae0e7bb01c39e75e860" data-wf-site="6220244ad6c7a7e70fbf6593" lang="en"><head><meta charset="utf-8"/><link href="https://cdn.prod.website-files.com" rel="preconnect" crossorigin="anonymous"/><title>Not Found</title><meta content="Not Found" property="og:title"/><meta content="Not Found" name="twitter:title"/><meta content="width=device-width, initial-scale=1" name="viewport"/><link href="https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/css/mostafaelbermawy.webflow.shared.e3c56e1bd.min.css" rel="stylesheet" type="text/css" integrity="sha384-48VuG9dseR8qNYtj9KQDHxqsZMwQwTLbWSQ6F6S8LO58hxS9BLvNDmvtYiGzWOAR" crossorigin="anonymous"/><link href="https://fonts.googleapis.com" rel="preconnect"/><link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous"/><script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script><script type="text/javascript">WebFont.load({  google: {    families: ["Cousine:400,700","Special Elite:400"]  }});</script><script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script><link href="https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/6228dd6ea3829932e78b6629_FAVICON.png" rel="shortcut icon" type="image/x-icon"/><link href="https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/655dd8ecd3b75f3e206e9a05_6228dd6ea3829932e78b6629_FAVICON.png" rel="apple-touch-icon"/><link href="https://bermawy.com/404" rel="canonical"/><script>(function(w,i,g){w[g]=w[g]||[];if(typeof w[g].push=='function')w[g].push.apply(w[g],Array.isArray(i)?i:[i]);})(window,['G-QHSFP99DXH'],'google_tags_first_party');</script><script async="" src="/nvhc9u4gxsagNjIyMDI0NGFkNmM3YTdlNzBmYmY2NTkz/hJYhJcN01Scu6HdI19B7EX7Xhow"></script><script type="text/javascript">window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('set', 'developer_id.dZGVlNj', true);gtag('set', 'developer_id.dYWYxNW', true);gtag('js', new Date());gtag('config', 'G-QHSFP99DXH');</script><!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-ML77D4V');</script>
<!-- End Google Tag Manager -->

<style>
/* ============================================
   GLOBAL — Scroll behavior
   ============================================ */
html {
  scroll-behavior: auto !important;
}

/* ============================================
   GLOBAL — Custom Scrollbar
   ============================================ */
::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-track {
  background: #F9F9F9;
  border: 1px solid #BDBDBD;
}

::-webkit-scrollbar-thumb {
  background: #E6F3FF;
  border: 1px solid #345AAA;
  border-radius: 0px;
}

::-webkit-scrollbar-thumb:hover {
  background: #345AAA;
}

@media (max-width: 767px) {
  .w-dyn-list,
  .w-dyn-items {
    overflow: scroll !important;
    scrollbar-width: none !important;
  }

  .w-dyn-list::-webkit-scrollbar,
  .w-dyn-items::-webkit-scrollbar {
    display: none !important;
  }
}

/* ============================================
   HERO — Photo Hover Cycle (2 states)
   ============================================ */
.photo-wrap {
  position: relative;
  cursor: pointer;
}

.photo-hover-2 {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0;
}

.photo-wrap:hover .photo-default {
  animation: cyclePhoto 1s steps(1) infinite;
}

.photo-wrap:hover .photo-hover-2 {
  animation: cyclePhoto 1s steps(1) 0.5s infinite;
}

@keyframes cyclePhoto {
  0%, 49% { opacity: 1; }
  50%, 100% { opacity: 0; }
}

/* ============================================
   NAVBAR — Transparent to Blur on Scroll
   ============================================ */
.navbar-3 {
  background: transparent !important;
  transition: background 0.3s ease, backdrop-filter 0.3s ease;
}

.navbar-3.is-scrolled {
  background: rgba(255, 255, 255, 0.7) !important;
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
}

/* ============================================
   NAVBAR — Mobile Hamburger / Exit Icon Swap
   ============================================ */
.navbar-button {
  background-image: url('https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/icon-hamburger.svg');
}

.navbar-button.w--open {
  background-image: url('https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/6a43e436d16bd8871c5813e2_ICONS%3DExit%2C%20State%3DPressed.svg');
}

/* ============================================
   ARTICLES — Glasses Icon (Default / Hover / Pressed)
   ============================================ */
.glasses-wrap {
  cursor: pointer;
  overflow: hidden;
}

.glasses-hover,
.glasses-pressed {
  opacity: 0 !important;
  transition: opacity 0.15s ease;
}

.glasses-default {
  opacity: 1 !important;
  transition: opacity 0.15s ease;
  display: block;
}

.glasses-wrap:hover .glasses-default { opacity: 0 !important; }
.glasses-wrap:hover .glasses-hover { opacity: 1 !important; }
.glasses-wrap:hover .glasses-pressed { opacity: 0 !important; }

.glasses-wrap:active .glasses-default { opacity: 0 !important; }
.glasses-wrap:active .glasses-hover { opacity: 0 !important; }
.glasses-wrap:active .glasses-pressed { opacity: 1 !important; }

/* ============================================
   MEDIA TABS — Mobile Dropdown
   ============================================ */
@media (max-width: 768px) {
  .tabs-menu-2 {
    display: none !important;
  }
  .tabs-dropdown {
    display: block !important;
  }
}

.tabs-dropdown {
  display: none;
  position: relative;
  width: 100%;
  z-index: 10;
  margin-bottom: 16px;
}

.tabs-dropdown-btn {
  width: 100%;
  height: 40px;
  padding: 10px 16px;
  background: #345AAA;
  color: #F9F9F9;
  font-family: 'Cousine', Courier New, monospace;
  font-size: 12px;
  font-weight: 700;
  text-transform: lowercase;
  letter-spacing: 2px;
  line-height: 1.64;
  border: none;
  cursor: pointer;
  text-align: left;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-sizing: border-box;
}

.tabs-dropdown-btn .tabs-dropdown-icon {
  font-size: 18px;
  font-weight: 300;
  line-height: 1;
}

.tabs-dropdown-list {
  display: none;
  flex-direction: column;
  position: relative;
  width: 100%;
  z-index: 100;
}

.tabs-dropdown-list.is-open {
  display: flex;
}

.tabs-dropdown-option {
  height: 40px;
  padding: 10px 16px;
  font-family: 'Cousine', Courier New, monospace;
  font-size: 12px;
  font-weight: 700;
  text-transform: lowercase;
  letter-spacing: 2px;
  line-height: 1.64;
  color: #345AAA;
  cursor: pointer;
  background: #E6F3FF;
  border-left: 1px solid #345AAA;
  border-right: 1px solid #345AAA;
  border-bottom: 1px solid #345AAA;
  box-sizing: border-box;
  display: flex;
  align-items: center;
}

.tabs-dropdown-option:hover,
.tabs-dropdown-option.is-active {
  background: #345AAA;
  color: #F9F9F9;
}

</style></head><body><script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=6220244ad6c7a7e70fbf6593" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script><script src="https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/js/webflow.schunk.56cc6380bad280e6.js" type="text/javascript" integrity="sha384-1bfHVu0BW/T8ibNTGjdGo/y2VAuLPdfTyUYt5NLF9tvQa9uUM0HVSHACOYZL+Oi1" crossorigin="anonymous"></script><script src="https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/js/webflow.a9ba356d.d790faab5eca85f2.js" type="text/javascript" integrity="sha384-8hwrC/NV4OSVSidC9MTWLDeeg1jSOl1uAsJFw5gGTgUPrsQC46VOTgPqiwYSOKAh" crossorigin="anonymous"></script><!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-ML77D4V"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<script>
window.addEventListener('scroll', function() {
  var navbar = document.querySelector('.navbar-3');
  if (!navbar) return;
  
  if (window.scrollY > 20) {
    navbar.classList.add('is-scrolled');
  } else {
    navbar.classList.remove('is-scrolled');
  }
});
</script>
<!-- Video Modal -->
<div id="video-modal" style="display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);z-index:9999;align-items:center;justify-content:center;">
  <div style="position:relative;width:90%;max-width:900px;aspect-ratio:16/9;">
    <iframe id="modal-iframe" src="" frameborder="0" allow="autoplay;encrypted-media" allowfullscreen style="width:100%;height:100%;border:none;"></iframe>
    <button id="modal-close" style="position:absolute;top:-44px;right:0;background:none;border:none;color:#fff;font-size:16px;cursor:pointer;font-family:Courier New,monospace;letter-spacing:0.05em;">✕ CLOSE</button>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {

  // ─── TABS DROPDOWN (mobile) ───────────────────────────────────
  var tabsWrapper = document.querySelector('.tabs-2');
  if (tabsWrapper) {
    var tabLinks = tabsWrapper.querySelectorAll('.w-tab-link');
    var tabLabels = [];
    tabLinks.forEach(function(link) {
      tabLabels.push(link.textContent.trim());
    });

    var dropdown = document.createElement('div');
    dropdown.className = 'tabs-dropdown';

    var btn = document.createElement('button');
    btn.className = 'tabs-dropdown-btn';
    btn.innerHTML = tabLabels[0] + ' <span class="tabs-dropdown-icon">+</span>';

    var list = document.createElement('div');
    list.className = 'tabs-dropdown-list';

    tabLabels.forEach(function(label, i) {
      var option = document.createElement('div');
      option.className = 'tabs-dropdown-option' + (i === 0 ? ' is-active' : '');
      option.textContent = label;
      option.addEventListener('click', function() {
        btn.innerHTML = label + ' <span class="tabs-dropdown-icon">+</span>';
        list.classList.remove('is-open');
        btn.querySelector('.tabs-dropdown-icon').textContent = '+';
        list.querySelectorAll('.tabs-dropdown-option').forEach(function(opt) {
          opt.classList.remove('is-active');
        });
        option.classList.add('is-active');
        tabLinks[i].click();
      });
      list.appendChild(option);
    });

    btn.addEventListener('click', function() {
      var isOpen = list.classList.toggle('is-open');
      btn.querySelector('.tabs-dropdown-icon').textContent = isOpen ? '−' : '+';
    });

    document.addEventListener('click', function(e) {
      if (!dropdown.contains(e.target)) {
        list.classList.remove('is-open');
        btn.querySelector('.tabs-dropdown-icon').textContent = '+';
      }
    });

    dropdown.appendChild(btn);
    dropdown.appendChild(list);
    tabsWrapper.parentNode.insertBefore(dropdown, tabsWrapper);
  }

  // ─── GAMEBOY PLAYER ───────────────────────────────────────────
  var modal = document.getElementById('video-modal');
  var modalIframe = document.getElementById('modal-iframe');
  var modalClose = document.getElementById('modal-close');

  var playDefault = 'https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/6a4b94251c696d519718c0af_ICONS%3DPLAY%20ICON%2C%20State%3DDefault%20(1).svg';
  var playHover = 'https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/6a4b9425396a09892fb71717_ICONS%3DPLAY%20ICON%2C%20State%3DHover%20(1).svg';

  function convertToEmbed(url) {
    if (!url) return '';
    if (url.includes('watch?v=')) {
      var videoId = url.split('watch?v=')[1].split('&')[0];
      return 'https://www.youtube.com/embed/' + videoId;
    }
    if (url.includes('youtu.be/')) {
      var videoId = url.split('youtu.be/')[1].split('?')[0];
      return 'https://www.youtube.com/embed/' + videoId;
    }
    return url;
  }

  function openModal(url) {
    var embedUrl = convertToEmbed(url) + '?autoplay=1&rel=0';
    modalIframe.src = embedUrl;
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  function closeModal() {
    modal.style.display = 'none';
    modalIframe.src = '';
    document.body.style.overflow = '';
  }

  function updateScreen(screenDiv, items, index, isInspiration) {
    if (!items[index] || !screenDiv) return;
    var thumbImg = items[index].querySelector('.media-item-thumb');
    var thumbSrc = thumbImg ? thumbImg.src : '';
    var videoUrl = items[index].getAttribute('data-video') || '';

    if (isInspiration) {
      screenDiv.innerHTML =
        '<div class="gameboy-poster" style="width:100%;height:100%;position:relative;display:flex;align-items:center;justify-content:center;background:#FAF9F6;">' +
          '<img src="' + thumbSrc + '" style="height:100%;width:auto;object-fit:contain;display:block;">' +
        '</div>';
    } else {
      screenDiv.innerHTML =
        '<div class="gameboy-poster" style="width:100%;height:100%;position:relative;cursor:pointer;">' +
          '<img src="' + thumbSrc + '" style="width:100%;height:100%;object-fit:cover;display:block;">' +
          '<img class="gameboy-play-icon" src="' + playDefault + '" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:48px;height:48px;pointer-events:none;transition:opacity 0.2s;">' +
        '</div>';

      var poster = screenDiv.querySelector('.gameboy-poster');
      var playIcon = screenDiv.querySelector('.gameboy-play-icon');

      poster.addEventListener('mouseenter', function() {
        playIcon.src = playHover;
      });
      poster.addEventListener('mouseleave', function() {
        playIcon.src = playDefault;
      });
      poster.addEventListener('click', function(e) {
        e.stopPropagation();
        if (videoUrl) openModal(videoUrl);
      });
    }
  }

  function initGameboy(pane, skipInitialScroll) {
    var items = pane.querySelectorAll('.media-item');
    var screenDiv = pane.querySelector('.gameboy-screen');
    var btnA = pane.querySelector('.gameboy-btn-a');
    var btnB = pane.querySelector('.gameboy-btn-b');
    var btnStart = pane.querySelector('.gameboy-btn-start');
    var current = 0;

    var isInspiration = pane.querySelector('.media-item.insp') !== null;

    if (!items.length || !screenDiv) return;

    function setActive(index) {
      items.forEach(function(item) {
        item.classList.remove('media-item-active');
      });
      if (items[index]) items[index].classList.add('media-item-active');
    }

    function activate(index, skipScroll) {
      current = index;
      setActive(index);
      updateScreen(screenDiv, items, index, isInspiration);
      if (!skipScroll && items[index] && window.innerWidth > 767) {
        items[index].scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    }

    items.forEach(function(item, i) {
      item.addEventListener('click', function(e) {
        if (e.target.closest('.gameboy-screen')) return;
        activate(i, false);
      });
    });

    if (btnA) {
      btnA.addEventListener('click', function(e) {
        e.stopPropagation();
        activate((current + 1) % items.length, false);
      });
    }

    if (btnB) {
      btnB.addEventListener('click', function(e) {
        e.stopPropagation();
        activate((current - 1 + items.length) % items.length, false);
      });
    }

    if (btnStart) {
      btnStart.addEventListener('click', function(e) {
        e.stopPropagation();
        if (isInspiration) return;
        var videoUrl = items[current] ? items[current].getAttribute('data-video') : '';
        if (videoUrl) openModal(videoUrl);
      });
    }

    // Always skip scroll on initial load
    activate(0, true);
  }

  // Init all tab panes with a gameboy-screen
  var panes = document.querySelectorAll('.w-tab-pane');
  panes.forEach(function(pane) {
    if (pane.querySelector('.gameboy-screen')) {
      initGameboy(pane, true);
    }
  });

  // Re-init on tab change — always skip scroll
  document.addEventListener('click', function(e) {
    var tabLink = e.target.closest('.w-tab-link');
    if (!tabLink) return;
    setTimeout(function() {
      var activePanes = document.querySelectorAll('.w-tab-pane.w--tab-active');
      activePanes.forEach(function(pane) {
        if (pane.querySelector('.gameboy-screen')) {
          initGameboy(pane, true);
        }
      });
    }, 100);
  });

  // Modal controls
  if (modal) {
    if (modalClose) modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', function(e) {
      if (e.target === modal) closeModal();
    });
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') closeModal();
    });
  }

});
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var navBtn = document.querySelector('.navbar-button');
  if (!navBtn) return;

  var closeIconUrl = 'https://cdn.prod.website-files.com/6220244ad6c7a7e70fbf6593/6a4b9a052b662dcbfd992b4a_ICONS%3DExit%2C%20State%3DPressed%20(1).svg';

  function updateIcon() {
    var isOpen = navBtn.classList.contains('w--open');
    var iconEl = navBtn.querySelector('.w-icon-nav-menu');

    if (isOpen) {
      if (iconEl) {
        iconEl.style.display = 'none';
      }
      if (!navBtn.querySelector('.nav-close-icon')) {
        var img = document.createElement('img');
        img.src = closeIconUrl;
        img.className = 'nav-close-icon';
        img.style.width = '24px';
        img.style.height = '24px';
        img.style.display = 'block';
        navBtn.appendChild(img);
      }
    } else {
      if (iconEl) {
        iconEl.style.display = 'block';
      }
      var closeImg = navBtn.querySelector('.nav-close-icon');
      if (closeImg) closeImg.remove();
    }
  }

  navBtn.addEventListener('click', function() {
    // Wait a tick for Webflow to toggle the w--open class first
    setTimeout(updateIcon, 10);
  });
});
</script></body></html>